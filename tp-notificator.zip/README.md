# Guild Wars 2 Trading Post Notificator
![version 1.1.6.0](https://img.shields.io/badge/version-1.1.6.0-green.svg) ![build passing](https://img.shields.io/badge/build-passing-brightgreen.svg) ![jquery 2.2.0](https://img.shields.io/badge/jquery-2.2.0-blue.svg) ![bootstrap 4.0.0.a2](https://img.shields.io/badge/bootstrap-4.0.0%20alpha%202-blue.svg) ![handlebars 4.0.5](https://img.shields.io/badge/handlebars-4.0.5-blue.svg) ![fontAwesome 4.5.0](https://img.shields.io/badge/font%20awesome-4.5.0-blue.svg)

You can get it at [Chrome store](https://chrome.google.com/webstore/detail/fmfminppfcknlpekeffahpnpfahmhojk) now for Google Chrome, Google Chrome Canary and Chromium.

Someone asked me to release extension on GitHub and I did so. I've never thought I will show its sources though, hope you'll be okay with my shitty code.

## Latest release - 1.1.6.0 - February 1, 2016
### Enhancements
* Removed some useless information from the debug page.
* Updated supported browsers FAQ page.

### Fixes
* Fixed a bug when you receive a huge amount of notifications after changing algorithm from 1st to 2nd. 
* Reduced the chance to get an error while loading any data from Guild Wars 2 servers. 

Check out previuos releases at [releases](https://github.com/terron-kun/tp-notificator/releases) page.
