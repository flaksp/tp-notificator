$("document").ready(function() {
	parse_templare("#changelog", "main");
});