$("document").ready(function() {
	parse_templare("#contacts", "main");
});