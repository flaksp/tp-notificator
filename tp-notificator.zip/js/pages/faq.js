$("document").ready(function() {
	parse_templare("#faq", "main");
});